<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
  <title>Raport - Import Nilai</title>
  <link rel="stylesheet" href="../css/layouts/pure-min.css">
  <link rel="stylesheet" href="../css/layouts/side-menu.css">
</head>

<body>
<div id="layout">
   <a href="#menu" id="menuLink" class="menu-link">
   <span></span>
   </a>
   <div id="menu">
      <div class="pure-menu pure-menu-open">
         <a class="pure-menu-heading" href="#"><center>Raport</center></a>
         <?
         $userid =$_POST['userid'];
#         $nama2  =$_GET['nama'];
         include ("../koneksi.inc.php");

         $query1=mysql_query("select * from guru where userid='$userid'" ,$koneksi);
         $jum=mysql_num_rows($query1);
         echo "<ul>";
               $row=mysql_fetch_array($query1);
               $password=$row["password"];
	       $pic=$userid;
	       $foto="../guru/".$pic.".jpg";
	       echo "<img src=\"$foto\" width=\"100%\" align=\"center\" border=\"0\"><center>";
	       echo $row["nama"];
	       echo "<br>";
	       echo "$userid</center>";
	       $nama=$row["nama"];
               echo "<li><a href=\"../login2.php?userid=$userid&pass=$password\">Depan</a></li>";
               echo "<li><a href=\"../index.php\">Logout</a></li>";
         echo "</ul>";
       echo "</div>";
    echo "</div>";

    # Bagian Utama

    ?>
    <div id="main">
        <div class="header">
            <h1><center>Aplikasi Raport</h1>
            <h2>Import Nilai</center></h2>
        </div>
        <div class=\"content\">

<?php
include "excel_reader2.php";
include ("../koneksi.inc.php");

#mysql_connect("localhost", $username, $password);
#mysql_select_db($database);

// file yang tadinya di upload, di simpan di temporary file PHP, file tersebut yang kita ambil
// dan baca dengan PHP Excel Class
$data = new Spreadsheet_Excel_Reader($_FILES['fileexcel']['tmp_name']);
$hasildata = $data->rowcount($sheet_index=0);
// default nilai 
$sukses = 0;
$gagal = 0;

for ($i=3; $i<=$hasildata; $i++)
{
  	$tag_nilai   = $data->val($i,2); 
  	$id_siswa    = $data->val($i,3);
  	$nilai       = $data->val($i,7);
  	$user        = $userid; 
  	$waktu_update= date('Y-m-d H:i:s');
  	if ($nilai=="A") { $nilai=4; }
    	if ($nilai=="B") { $nilai=3; }
      	if ($nilai=="C") { $nilai=2; }
  	if ($nilai=="D") { $nilai=1; }    	  		
	$query1 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai= '$tag_nilai'",$koneksi);
	$jum=0;
	if ($query1)
	{
	 	$jum=mysql_num_rows($query1);
	}
	if ($jum>0)
        {
		$proses="Update";
		$query3 = "Update nilai set nilai='$nilai', user='$user', waktu_update='$waktu_update' where id_siswa='$id_siswa' and tag_nilai='$tag_nilai'";
		$hasil = mysql_query($query3);
	}
	else
	{
		$proses="insert";
		$tag=$id_siswa.$tag_nilai;		
		$query2 = "INSERT INTO nilai  VALUES (null,'$id_siswa','$tag_nilai','$nilai', '$user', '$waktu_update','$tag')";
		$hasil = mysql_query($query2);
	}
	if ($hasildata) $sukses++;
	else $gagal++;
  
#	echo "<pre>";
#	print_r($query3);
#	echo "</pre>";
}
echo "<b>import data selesai.</b> <br>";
echo "Data yang berhasil di $proses : " . $sukses .  "<br>";
echo "Data yang gagal $proses : ".$gagal .  "<br>";
?>


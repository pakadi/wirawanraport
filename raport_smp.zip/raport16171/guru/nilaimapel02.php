<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
  <title>Raport - Tampilkan daftar siswa</title>
  <link rel="stylesheet" href="../css/layouts/pure-min.css">
  <link rel="stylesheet" href="../css/layouts/side-menu.css">
</head>

<body>
<div id="layout">
   <a href="#menu" id="menuLink" class="menu-link">
   <span></span>
   </a>
   <div id="menu">
      <div class="pure-menu pure-menu-open">
         <a class="pure-menu-heading" href="#"><center>Raport</center></a>
         <?
         $userid   ="G15";
         $tag_nil  ="15162B08%";
	 $rombel   ="9%";
	 $alias    ="AGAMA";
	 $jumlah_kd=2;
         include ("../koneksi.inc.php");

         $query1=mysql_query("select * from guru where userid='$userid'" ,$koneksi);
         $jum=mysql_num_rows($query1);
         echo "<ul>";
               $row=mysql_fetch_array($query1);
               $password=$row["password"];
	       $pic=$userid;
	       $foto="../guru/".$pic.".jpg";
	       echo "<img src=\"$foto\" width=\"100%\" align=\"center\" border=\"0\"><center>";
	       echo $row["nama"];
	       echo "<br>";
	       echo "$userid</center>";
	       $nama=$row["nama"];
               echo "<li><a href=\"../index.php\">Logout</a></li>";
         echo "</ul>";
       echo "</div>";
    echo "</div>";
    # Bagian Utama
    ?>
    <div id="main">
        <div class="header">
            <h1><center>Aplikasi Raport</h1>
            <h2>Nilai per rombongan belajar</center></h2>
        </div>
        <div class=\"content\">
<?php

#$kodenilai=substr($tagnilai,8,3);
#$query2=mysql_query("select * from jenis_nilai where kodenilai like '$kodenilai'",$koneksi);
#while ($row2=mysql_fetch_array($query2))
#{
#	$jenistes=$row2["jenisnilai"];
#}


echo "Mapel = $alias  |   Rombel : $rombel";
# echo "<a href=\"export01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\"> ---- Export ke excel</a>";
$query2=mysql_query("select * from siswa where rombel_14 like '$rombel' order by nama",$koneksi);
$jumlah=mysql_num_rows($query2);
$jmkolom=9+($jumlah_kd*3);
echo "<table class=\"pure-table\">";
echo "<thead><tr>";
echo "<th rowspan=2>No</th>
   <th rowspan=2>Id Siswa</th>
   <th rowspan=2>Nama Peserta</th>
   <th rowspan=2>LP</th>
   <th colspan=$jmkolom align=center>Nilai</th>
   </tr><tr>";
$h=1;
for ($h ; $h <= $jumlah_kd ; $h++)
{
	$varnil="H0".$h;
	echo  "<th>$varnil</th>";
}
$t=1;
for ($t ; $t <= $jumlah_kd ; $t++)
{
	$varnil="T0".$t;
	echo  "<th>$varnil</th>";
}
echo "<th>Obs</th>
      <th>Tmn</th>
      <th>Jur</th>
      <th>Diri</th>";
$s=5;
$batas=$jumlah_kd+4;
for ($s ; $s <= $batas ; $s++)
{
	$varnil="S0".$s;
	echo  "<th>$varnil</th>";
}
echo "<th>Port</th>
      <th>Pryk</th>
      <th>Unjk</th>
      <th>UTS</th>
      <th>UAS</th></tr>";
echo "</thead>";
$no=0;
while ($row2=mysql_fetch_array($query2))
{
	$no++;
	$nama   =$row2["nama"];
	$id_siswa=$row2["userid"];
	$lp     =$row2["LP"];
	if ($no & 1)
	{
		echo "<tr>";
	}
	else
	{
		echo "<tr class=\"pure-table-odd\">";
	}
	echo "<td>$no</td>";
	echo "<td>$id_siswa</td>";
	echo "<td>$nama</td>";
	echo "<td>$lp</td>";	
#--nilai harian
	$h=1;
	for ($h ; $h <= $jumlah_kd ; $h++)
	{
		$varnil="H0".$h;
		$tag_nilai=$tag_nil.$varnil;
		$query3 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai like '$tag_nilai'",$koneksi);
		if ($query3)
		{
			$row3=mysql_fetch_array($query3);
			$nilai=$row3["nilai"];
		}
		else
		{
			$nilai=1;
		}
		echo "<td>$nilai</td>";	
	}
#--nilai tugas
	$t=1;
	for ($t ; $t <= $jumlah_kd ; $t++)
	{
		$varnil="T0".$t;
		$tag_nilai=$tag_nil.$varnil;
		$query4 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai like '$tag_nilai'",$koneksi);
		if ($query4)
		{
			$row4=mysql_fetch_array($query4);
			$nilai=$row4["nilai"];
		}
		else
		{
			$nilai=1;
		}
		echo "<td>$nilai</td>";
	}
#--nilai sikap
	$tag_nilai=$tag_nil."S01";
	$query5 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai like '$tag_nilai'",$koneksi);
	$row5=mysql_fetch_array($query5);
	$nilai=$row5["nilai"];
 	if ($nilai==1) { $nilai="D"; }
    	if ($nilai==2) { $nilai="C"; }
      	if ($nilai==3) { $nilai="B"; }
  	if ($nilai==4) { $nilai="A"; }
	echo "<td>$nilai</td>";
	$tag_nilai=$tag_nil."S02";
	$query6 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai like '$tag_nilai'",$koneksi);
	$row6=mysql_fetch_array($query6);
	$nilai=$row6["nilai"];
	if ($nilai==1) { $nilai="D"; }
    	if ($nilai==2) { $nilai="C"; }
      	if ($nilai==3) { $nilai="B"; }
  	if ($nilai==4) { $nilai="A"; }
	echo "<td>$nilai</td>";
	$tag_nilai=$tag_nil."S03";
	$query5 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai like '$tag_nilai'",$koneksi);
	$row5=mysql_fetch_array($query5);
	$nilai=$row5["nilai"];
 	if ($nilai==1) { $nilai="D"; }
    	if ($nilai==2) { $nilai="C"; }
      	if ($nilai==3) { $nilai="B"; }
  	if ($nilai==4) { $nilai="A"; } 	
	echo "<td>$nilai</td>";
	$tag_nilai=$tag_nil."S04";
	$query6 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai like '$tag_nilai'",$koneksi);
	$row6=mysql_fetch_array($query6);
	$nilai=$row6["nilai"];
	if ($nilai==1) { $nilai="D"; }
    	if ($nilai==2) { $nilai="C"; }
      	if ($nilai==3) { $nilai="B"; }
  	if ($nilai==4) { $nilai="A"; } 
	echo "<td>$nilai</td>";
	$s=5;
	for ($s ; $s <= $jumlah_kd+4 ; $s++)
	{
		$varnil="S0".$s;
		$tag_nilai=$tag_nil.$varnil;
		$query4 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai like '$tag_nilai'",$koneksi);
		if ($query4)
		{
			$row4=mysql_fetch_array($query4);
			$nilai=$row4["nilai"];
		}
		else
		{
			$nilai=1;
		}
		if ($nilai==1) { $nilai="D"; }
    		if ($nilai==2) { $nilai="C"; }
     	 	if ($nilai==3) { $nilai="B"; }
  		if ($nilai==4) { $nilai="A"; } 
		echo "<td>$nilai</td>";
	}
#--nilai Keterampilan
	$tag_nilai=$tag_nil."P01";
	$query6 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai like '$tag_nilai'",$koneksi);
	$row6=mysql_fetch_array($query6);
	$nilai=$row6["nilai"]; 
	echo "<td>$nilai</td>";
	$tag_nilai=$tag_nil."P02";
	$query6 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai like '$tag_nilai'",$koneksi);
	$row6=mysql_fetch_array($query6);
	$nilai=$row6["nilai"]; 
	echo "<td>$nilai</td>";
	$tag_nilai=$tag_nil."P03";
	$query6 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai like '$tag_nilai'",$koneksi);
	$row6=mysql_fetch_array($query6);
	$nilai=$row6["nilai"]; 
	echo "<td>$nilai</td>";
	$tag_nilai=$tag_nil."U01";
	$query6 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai like '$tag_nilai'",$koneksi);
	$row6=mysql_fetch_array($query6);
	$nilai=$row6["nilai"]; 
	echo "<td>$nilai</td>";
	$tag_nilai=$tag_nil."U02";
	$query6 = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai like '$tag_nilai'",$koneksi);
	$row6=mysql_fetch_array($query6);
	$nilai=$row6["nilai"]; 
	echo "<td>$nilai</td>";
	echo "</tr>";
}
echo "</table>";
?>
       </div>
   </div>
</div>
<script src="../js/ui.js"></script>
</body>
</html>

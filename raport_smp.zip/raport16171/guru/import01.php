<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
  <title>Raport - Import Nilai</title>
  <link rel="stylesheet" href="../css/layouts/pure-min.css">
  <link rel="stylesheet" href="../css/layouts/side-menu.css">
</head>

<body>
<div id="layout">
   <a href="#menu" id="menuLink" class="menu-link">
   <span></span>
   </a>
   <div id="menu">
      <div class="pure-menu pure-menu-open">
         <a class="pure-menu-heading" href="#"><center>Raport</center></a>
         <?
         $userid =$_GET['userid'];
#         $nama2  =$_GET['nama'];
         include ("../koneksi.inc.php");

         $query1=mysql_query("select * from guru where userid='$userid'" ,$koneksi);
         $jum=mysql_num_rows($query1);
         echo "<ul>";
               $row=mysql_fetch_array($query1);
               $password=$row["password"];
	       $pic=$userid;
	       $foto="../guru/".$pic.".jpg";
	       echo "<img src=\"$foto\" width=\"100%\" align=\"center\" border=\"0\"><center>";
	       echo $row["nama"];
	       echo "<br>";
	       echo "$userid</center>";
	       $nama=$row["nama"];
               echo "<li><a href=\"../login2.php?userid=$userid&pass=$password\">Depan</a></li>";
               echo "<li><a href=\"../index.php\">Logout</a></li>";
         echo "</ul>";
       echo "</div>";
    echo "</div>";

    # Bagian Utama

    ?>
    <div id="main">
        <div class="header">
            <h1><center>Aplikasi Raport</h1>
            <h2>Import Nilai</center></h2>
        </div>
        <div class=\"content\">

<form method="post" enctype="multipart/form-data" action="import02.php">
<? echo "<input type=\"hidden\" name=\"userid\" value=\"$userid\">"; ?>
Pilih File Excel*: <input name="fileexcel" type="file"> <input name="upload" type="submit" value="Import">
</form>
* file yang bisa di import adalah .xls (Excel 2003).
 </div>
   </div>
</div>
<script src="../js/ui.js"></script>
</body>
</html>

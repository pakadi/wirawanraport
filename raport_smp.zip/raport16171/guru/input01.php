<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
  <title>Raport - Tampilkan daftar siswa</title>
  <link rel="stylesheet" href="../css/layouts/pure-min.css">
  <link rel="stylesheet" href="../css/layouts/side-menu.css">
</head>

<body>
<div id="layout">
   <a href="#menu" id="menuLink" class="menu-link">
   <span></span>
   </a>
   <div id="menu">
      <div class="pure-menu pure-menu-open">
         <a class="pure-menu-heading" href="#"><center>Raport</center></a>
         <?
         $userid   =$_GET['userid'];
         $tag_nilai =$_GET['tagnilai'];
	 $rombel   =$_GET['rombel'];
	 $mapel    =$_GET['mapel'];
         include ("../koneksi.inc.php");

         $query1=mysql_query("select * from guru where userid='$userid'" ,$koneksi);
         $jum=mysql_num_rows($query1);
         echo "<ul>";
               $row=mysql_fetch_array($query1);
               $password=$row["password"];
	       $pic=$userid;
	       $foto="../guru/".$pic.".jpg";
	       echo "<img src=\"$foto\" width=\"100%\" align=\"center\" border=\"0\"><center>";
	       echo $row["nama"];
	       echo "<br>";
	       echo "$userid</center>";
	       $nama=$row["nama"];
               echo "<li><a href=\"../index.php\">Logout</a></li>";
         echo "</ul>";
       echo "</div>";
    echo "</div>";
    # Bagian Utama
    ?>
    <div id="main">
        <div class="header">
            <h1><center>Aplikasi Raport</h1>
            <h2>Nilai per rombongan belajar</center></h2>
        </div>
        <div class=\"content\">
<?php

$kodenilai=substr($tag_nilai,8,3);
$query=mysql_query("select * from jenis_nilai where kodenilai like '$kodenilai'",$koneksi);
while ($row=mysql_fetch_array($query))
{
	$jenistes=$row["jenisnilai"];
}
echo "Mapel: $mapel ($rombel)<br>Jenis: $jenistes ($kodenilai)";
$query2=mysql_query("select * from siswa where rombel_14='$rombel' order by nama",$koneksi);
$jumlah=mysql_num_rows($query2);

echo "<table class=\"pure-table\">";
echo "<thead><tr>";
echo "<th>No</th>
   <th>Nama Peserta</th>
   <th>LP</th>";
#   <th>Rombel</th>";
if (substr($kodenilai,0,1)=="S")
{
	echo "<th>Nilai</th>";
}
else
{
	echo "<th>Nilai</th>";
}
echo "</tr></thead>";
$no=0;
echo "<form class=\"pure-form pure-form-stacked\" name=\"formnilai\" method=\"post\" action=\"updatenilai.php\">";
while ($row2=mysql_fetch_array($query2))
{
	$no++;
	if ($no & 1)
	{
		echo "<tr>";
	}
	else
	{
		echo "<tr class=\"pure-table-odd\">";
	}

	$nama    =$row2["nama"];
	$id_siswa=$row2["userid"];
	$lp      =$row2["LP"];
	$query3  = mysql_query("select * from nilai where id_siswa = '$id_siswa' and tag_nilai= '$tag_nilai'",$koneksi);
	if ($query3)
	{
		$row3=mysql_fetch_array($query3);
		$nilai=$row3["nilai"];
	}
	else
	{
		$nilai=1;
	}
 	if ($nilai==1) { $nilai="D"; }
    	if ($nilai==2) { $nilai="C"; }
      	if ($nilai==3) { $nilai="B"; }
  	if ($nilai==4) { $nilai="A"; } 
	echo "<td>$no</td>";
#	echo "<td>$tag_nilai</td>";
#	echo "<td>$id_siswa</td>";
	echo "<td>$nama</td>";
	echo "<td>$lp</td>";
#	echo "<td>$rombel</td>";
	$nilai2    ="nilai2[$no]";
	$id_siswa2 ="id_siswa2[$no]";
	if (substr($kodenilai,0,1)=="S")
	{
		$a=""; $b=""; $c=""; $d=""; $e="";
		if ($nilai=="A") { $a="selected"; } 
		if ($nilai=="B") { $b="selected"; } 
		if ($nilai=="C") { $c="selected"; } 
		if ($nilai=="D") { $d="selected"; } 
		if ($nilai=="E") { $e="selected"; } 
                echo "<td><select id=\"nilai\" name=\"$nilai2\" value=\"$nilai\">";
                echo "<option value=4 $a>A</option>";
                echo "<option value=3 $b>B</option>";
                echo "<option value=2 $c>C</option>";
                echo "<option value=1 $d>D</option>";
                echo "<option value=0 $e>E</option>";
                echo "</select></td>";
	}
	else
	{
		echo "<td><input type=\"text\" placeholder=\"0-100\" size=\"5\" name=\"$nilai2\" value=\"$nilai\"></td></div>";
	}
	echo "<input type=\"hidden\" name=\"$id_siswa2\" value=\"$id_siswa\">";
	echo "</tr>";
}
echo "</table>";
echo "<input type=\"hidden\" name=\"no\" value=\"$no\">";
echo "<input type=\"hidden\" name=\"tag_nilai\" value=\"$tag_nilai\">";
echo "<input type=\"hidden\" name=\"userid\" value=\"$userid\">";
echo "<br><input class=\"pure-button pure-button-primary\" type=\"submit\" name=\"submit\" value=\"selesai\">";
echo "</form><p>";
?>
       </div>
   </div>
</div>
<script src="../js/ui.js"></script>
</body>
</html>

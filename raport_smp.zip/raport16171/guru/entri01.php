<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
  <title>Raport - Entri daftar siswa</title>
  <link rel="stylesheet" href="../css/layouts/pure-min.css">
  <link rel="stylesheet" href="../css/layouts/side-menu.css">
</head>

<body>
<div id="layout">
   <a href="#menu" id="menuLink" class="menu-link">
   <span></span>
   </a>
   <div id="menu">
      <div class="pure-menu pure-menu-open">
         <a class="pure-menu-heading" href="#"><center>Raport</center></a>
         <?
         $userid =$_GET['userid'];
#         $nama2  =$_GET['nama'];
         include ("../koneksi.inc.php");

         $query1=mysql_query("select * from guru where userid='$userid'" ,$koneksi);
         $jum=mysql_num_rows($query1);
         echo "<ul>";
               $row=mysql_fetch_array($query1);
               $password=$row["password"];
	       $pic=$userid;
	       $foto="../guru/".$pic.".jpg";
	       echo "<img src=\"$foto\" width=\"100%\" align=\"center\" border=\"0\"><center>";
	       echo $row["nama"];
	       echo "<br>";
	       echo "$userid</center>";
	       $nama=$row["nama"];
               echo "<li><a href=\"../index.php\">Logout</a></li>";
         echo "</ul>";
       echo "</div>";
    echo "</div>";

    # Bagian Utama

    ?>

    <div id="main">
        <div class="header">
            <h1><center>Aplikasi Raport</h1>
            <h2>Entri Nilai</center></h2>
        </div>
        <div class=\"content\">
<?
echo "<br><table class=\"pure-table\">";
$query1=mysql_query("select * from tugas where kodeguru like '%$userid%' order by mapelrombel",$koneksi);

$jumlah=mysql_num_rows($query1);
echo "<thead><tr>";
echo "<th>No</th>
   <th>Thn Ajr</th>
   <th>Smt</th>
   <th>Mapel</th>
   <th>Rombel</th>
   </tr></thead>";
$no=0;
while ($row=mysql_fetch_array($query1))
{
	$no++;
	$tasemester=$row["tasemester"];
	$tahunajaran=substr($tasemester,0,4);
	$semester=substr($tasemester,4,1);
	$mapelrombel=$row["mapelrombel"];
	$kodemapel=substr($mapelrombel,0,3);
	$rombel=substr($mapelrombel,3,3);
	$jumlah_kd=$row["jumlah_kd"];
	$query2=mysql_query("select * from mapel where kodemapel='$kodemapel'", $koneksi);
	while ($row2=mysql_fetch_array($query2))
	{
		$mapel=$row2["mapel"];
		$alias=$row2["alias"];
	}
	echo "<tr>";
	echo "<td>$no</td>";
	echo "<td>$tahunajaran</td>";
	echo "<td>$semester</td>";
	echo "<td>$alias ($mapel)</td>";
	echo "<td>$rombel</td>";
	echo "</tr>";
	echo "<tr class=\"pure-table-odd\">";
	echo "<td colspan=2>";
#--Pengetahuan--
	echo "Pengetahuan";
	echo "</td><td colspan=3>";
	$h=1;
	for ($h ; $h <= $jumlah_kd ; $h++)
	{
		$tagnilai=$tasemester.$kodemapel."H0".$h;
		echo "<a href=\"input01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\">- KD$h</a>";
	}
	echo " Tugas : ";
	$t=1;
	for ($t ; $t <= $jumlah_kd ; $t++)
	{
		$tagnilai=$tasemester.$kodemapel."T0".$t;
		echo "<a href=\"input01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\">- KD$t</a>";
	}
	echo "</td></tr>";
#--Sikap--
	echo "<tr><td colspan=2>";
	echo "Sikap</td><td colspan=3>";
	$tagnilai=$tasemester.$kodemapel."S01";
	echo "<a href=\"input01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\"> - Observasi</a>";
	$tagnilai=$tasemester.$kodemapel."S02";
	echo "<a href=\"input01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\"> - P Teman</a>";
	$tagnilai=$tasemester.$kodemapel."S03";
	echo "<a href=\"input01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\"> - Jurnal</a>";
	$tagnilai=$tasemester.$kodemapel."S04";
	echo "<a href=\"input01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\"> - P Diri</a>";

	$s=5;
	$k=0;
	for ($s ; $s <= $jumlah_kd+4 ; $s++)
	{
		$k++;
		$tagnilai=$tasemester.$kodemapel."S0".$s;
		echo "<a href=\"input01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\">- KD$k</a>";
	}
	echo "</td></tr>";
#--Keterampilan
	echo "<tr class=\"pure-table-odd\"><td colspan=2>";
	echo "Keterampilan</td><td colspan=3>";
	$tagnilai=$tasemester.$kodemapel."P01";
	echo "<a href=\"input01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\"> - Portofolio</a>";
	$tagnilai=$tasemester.$kodemapel."P02";
	echo "<a href=\"input01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\"> - Proyek</a>";
	$tagnilai=$tasemester.$kodemapel."P03";
	echo "<a href=\"input01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\"> - Unjuk Kerja</a>";
	echo "</td></tr>";
#--Formatif--
	echo "<tr><td colspan=2>";
	echo "Formatif</td><td colspan=3>";
	$tagnilai=$tasemester.$kodemapel."U01";
	echo "<a href=\"input01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\"> - UTS</a>";
	$tagnilai=$tasemester.$kodemapel."U02";
	echo "<a href=\"input01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\"> - UAS</a>";
	echo "</td></tr>";
}
echo "</table>";
?>
       </div>
   </div>
</div>
<script src="../js/ui.js"></script>
</body>
</html>

type html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
  <title>Raport - Tampilkan daftar siswa</title>
  <link rel="stylesheet" href="../css/layouts/pure-min.css">
  <link rel="stylesheet" href="../css/layouts/side-menu.css">
</head>

<body>
<div id="layout">
   <a href="#menu" id="menuLink" class="menu-link">
   <span></span>
   </a>
   <div id="menu">
      <div class="pure-menu pure-menu-open">
         <a class="pure-menu-heading" href="#"><center>Raport</center></a>
         <?
         $userid    =$_POST['userid'];
         $no        =$_POST['no'];

	 include ("../koneksi.inc.php");
         $query1=mysql_query("select * from guru where userid='$userid'" ,$koneksi);
         $jum=mysql_num_rows($query1);
         echo "<ul>";
               $row=mysql_fetch_array($query1);
               $password=$row["password"];
	       $pic=$userid;
	       $foto="../guru/".$pic.".jpg";
	       echo "<img src=\"$foto\" width=\"100%\" align=\"center\" border=\"0\"><center>";
	       echo $row["nama"];
	       echo "<br>";
	       echo "$userid</center>";
	       $nama=$row["nama"];
               echo "<li><a href=\"../login2.php?userid=$userid&pass=$password\">Depan</a></li>";	       
               echo "<li><a href=\"../index.php\">Logout</a></li>";
         echo "</ul>";
       echo "</div>";
    echo "</div>";
    # Bagian Utama
    ?>
    <div id="main">
        <div class="header">
            <h1><center>Aplikasi Raport</h1>
            <h2>Update Nilai</center></h2>
        </div>
        <div class=\"content\">
<?php
$sukses=0;
$gagal=0;
for ($i=1; $i <= $no; $i++)
{
  	$id_siswa2   = $_POST['id_siswa2'];
	$sakit2      = $_POST['sakit2'];
	$izin2       = $_POST['izin2'];
	$alpa2       = $_POST['alpa2'];
  	$user        = $userid; 
	$id_siswa    = $id_siswa2[$i];
	$sakit       = $sakit2[$i];
	$izin        = $izin2[$i];
	$alpa        = $alpa2[$i];
  	$waktu_update= date('Y-m-d H:i:s');
	$query1 = mysql_query("select * from absen where id_siswa = '$id_siswa'",$koneksi);
	$jum=0;
	if ($query1)
	{
	 	$jum=mysql_num_rows($query1);
	}
	if ($jum>0)
        {
		$proses="Update";
		$query3 = "Update absen set sakit='$sakit', izin='$izin', alpa='$alpa', waktu_update='$waktu_update' where id_siswa='$id_siswa'";
		$hasil = mysql_query($query3);
	}
	else
	{
		$proses="insert";
		$query2 = "INSERT INTO absen  VALUES (null,'14152','$id_siswa','$sakit','$izin', '$alpa','', '$waktu_update')";
		$hasil = mysql_query($query2);
	}
#	echo "$tag_nilai - $id_siswa - $nilai<br>"; 
#	if ($nilai==0) { $gagal++; } else { $sukses++; }

}
echo "<b>data sudah masuk data selesai.</b> <br>";
echo "Data berhasil di $proses <br>";
?>
       </div>
   </div>
</div>
<script src="../js/ui.js"></script>
</body>
</html>

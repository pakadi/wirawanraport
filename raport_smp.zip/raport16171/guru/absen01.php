<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
  <title>Raport - Entri Absen</title>
  <link rel="stylesheet" href="../css/layouts/pure-min.css">
  <link rel="stylesheet" href="../css/layouts/side-menu.css">
</head>

<body>
<div id="layout">
   <a href="#menu" id="menuLink" class="menu-link">
   <span></span>
   </a>
   <div id="menu">
      <div class="pure-menu pure-menu-open">
         <a class="pure-menu-heading" href="#"><center>Raport</center></a>
         <?
         $userid   =$_GET['userid'];
	 $rombel   =$_GET['rombel'];
         include ("../koneksi.inc.php");

         $query1=mysql_query("select * from guru where userid='$userid'" ,$koneksi);
         $jum=mysql_num_rows($query1);
         echo "<ul>";
               $row=mysql_fetch_array($query1);
               $password=$row["password"];
	       $pic=$userid;
	       $foto="../guru/".$pic.".jpg";
	       echo "<img src=\"$foto\" width=\"100%\" align=\"center\" border=\"0\"><center>";
	       echo $row["nama"];
	       echo "<br>";
	       echo "$userid</center>";
	       $nama=$row["nama"];
               echo "<li><a href=\"../index.php\">Logout</a></li>";
         echo "</ul>";
       echo "</div>";
    echo "</div>";
    # Bagian Utama
    ?>
    <div id="main">
        <div class="header">
            <h1><center>Aplikasi Raport</h1>
            <h2>Masukkan data Absen</center></h2>
        </div>
        <div class=\"content\">
<?php
#echo "Mapel: $mapel ($rombel)<br>Jenis: $jenistes ($kodenilai)";
$query2=mysql_query("select * from siswa where rombel_14='$rombel' order by nama",$koneksi);
$jumlah=mysql_num_rows($query2);

echo "<table class=\"pure-table\">";
echo "<thead><tr>";
echo "<th>No</th>
   <th>Nama Peserta</th>
   <th>LP</th><th>Sakit</th><th>Izin</th><th>Alpa</th>";
echo "</tr></thead>";
$no=0;
echo "<form class=\"pure-form pure-form-stacked\" name=\"formnilai\" method=\"post\" action=\"updateabsen.php\">";
while ($row2=mysql_fetch_array($query2))
{
	$nama    =$row2["nama"];
	$id_siswa=$row2["userid"];
	$lp      =$row2["LP"];

	$no++;
	if ($no & 1)
	{
		echo "<tr>";
	}
	else
	{
		echo "<tr class=\"pure-table-odd\">";
	}

	$query3  = mysql_query("select * from absen where id_siswa = '$id_siswa'",$koneksi);
	$juml=mysql_num_rows($query3);
#	if ($juml>0)
#	{
		$row3=mysql_fetch_array($query3);
		$sakit=$row3["sakit"];
		$izin =$row3["izin"];
		$alpa =$row3["alpa"];
#	}
#	else
#	{
#		$sakit=0;
#		$izin =0;
#		$alpa =0;
#	}

	echo "<td>$no</td>";
	echo "<td>$nama</td>";
	echo "<td>$lp</td>";
	$id_siswa2="id_siswa2[$no]";
	$sakit2   ="sakit2[$no]";
	$izin2    ="izin2[$no]";
	$alpa2    ="alpa2[$no]";
	echo "<td><input type=\"text\" placeholder=\"sakit\" size=\"2\" name=\"$sakit2\" value=\"$sakit\"></td>";
	echo "<td><input type=\"text\" placeholder=\"izin\"  size=\"2\" name=\"$izin2\"  value=\"$izin\"></td>";
	echo "<td><input type=\"text\" placeholder=\"alpa\"  size=\"2\" name=\"$alpa2\"  value=\"$alpa\"></td></div>";
	echo "<input type=\"hidden\" name=\"$id_siswa2\" value=\"$id_siswa\">";
	echo "</tr>";
}
echo "</table>";
echo "<input type=\"hidden\" name=\"no\" value=\"$no\">";
#echo "<input type=\"hidden\" name=\"tag_nilai\" value=\"$tag_nilai\">";
echo "<input type=\"hidden\" name=\"userid\" value=\"$userid\">";
echo "<br><input class=\"pure-button pure-button-primary\" type=\"submit\" name=\"submit\" value=\"selesai\">";
echo "</form><p>";
?>
       </div>
   </div>
</div>
<script src="../js/ui.js"></script>
</body>
</html>

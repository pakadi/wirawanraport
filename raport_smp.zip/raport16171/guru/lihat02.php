<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
  <title>Raport - Tampilkan daftar siswa</title>
  <link rel="stylesheet" href="../css/layouts/pure-min.css">
  <link rel="stylesheet" href="../css/layouts/side-menu.css">
</head>

<body>
<div id="layout">
   <a href="#menu" id="menuLink" class="menu-link">
   <span></span>
   </a>
   <div id="menu">
      <div class="pure-menu pure-menu-open">
         <a class="pure-menu-heading" href="#"><center>Raport</center></a>
         <?
         $userid   =$_GET['userid'];
         $tagnilai =$_GET['tagnilai'];
	 $rombel   =$_GET['rombel'];
	 $mapel    =$_GET['mapel'];
         include ("../koneksi.inc.php");

         $query1=mysql_query("select * from guru where userid='$userid'" ,$koneksi);
         $jum=mysql_num_rows($query1);
         echo "<ul>";
               $row=mysql_fetch_array($query1);
               $password=$row["password"];
	       $pic=$userid;
	       $foto="../guru/".$pic.".jpg";
	       echo "<img src=\"$foto\" width=\"100%\" align=\"center\" border=\"0\"><center>";
	       echo $row["nama"];
	       echo "<br>";
	       echo "$userid</center>";
	       $nama=$row["nama"];
               echo "<li><a href=\"../index.php\">Logout</a></li>";
         echo "</ul>";
       echo "</div>";
    echo "</div>";
    # Bagian Utama
    ?>
    <div id="main">
        <div class="header">
            <h1><center>Aplikasi Raport</h1>
            <h2>Nilai per rombongan belajar</center></h2>
        </div>
        <div class=\"content\">
<?php

$kodenilai=substr($tagnilai,8,4);
$query2=mysql_query("select * from jenis_nilai where kodenilai like '$kodenilai'",$koneksi);
while ($row2=mysql_fetch_array($query2))
{
	$jenistes=$row2["jenisnilai"];
}
echo "Mapel = $mapel  |   Jenis : $jenistes ($kodenilai)";
echo "<a href=\"export01.php?tagnilai=$tagnilai&userid=$userid&rombel=$rombel&mapel=$mapel\"> ---- Export ke excel</a>";
$query2=mysql_query("select * from siswa where rombel_14='$rombel' order by nama",$koneksi);
$jumlah=mysql_num_rows($query2);

echo "<table class=\"pure-table\">";
echo "<thead><tr>";
echo "<th>No</th>
   <th>Tag Nilai</th>
   <th>Id Siswa</th>
   <th>Nama Peserta</th>
   <th>LP</th>
   <th>Rombel</th>";
if (substr($kodenilai,0,1)=="S")
{
	echo "<th>Nilai(A-D)</th>";
}
else
{
	echo "<th>Nilai</th>";
}
echo "</tr></thead>";
$no=0;
while ($row2=mysql_fetch_array($query2))
{
	$no++;
	$nama   =$row2["nama"];
	$idsiswa=$row2["userid"];
	$lp     =$row2["LP"];
	$query3 = mysql_query("select * from nilai where id_siswa = '$idsiswa' and tag_nilai= '$tagnilai'",$koneksi);
	if ($query3)
	{
		$row3=mysql_fetch_array($query3);
		$nilai=$row3["nilai"];
	}
	else
	{
		$nilai=1;
	}
 	if ($nilai==1) { $nilai="D"; }
    	if ($nilai==2) { $nilai="C"; }
      	if ($nilai==3) { $nilai="B"; }
  	if ($nilai==4) { $nilai="A"; } 
	echo "<tr><td>$no</td>";
	echo "<td>$tagnilai</td>";
	echo "<td>$idsiswa</td>";
	echo "<td>$nama</td>";
	echo "<td>$lp</td>";
	echo "<td>$rombel</td>";
	echo "<td>$nilai</td></tr>";
}
echo "</table>";
?>
       </div>
   </div>
</div>
<script src="../js/ui.js"></script>
</body>
</html>

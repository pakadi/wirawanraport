<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
  <title>Raport - Definisi KD</title>
  <link rel="stylesheet" href="../css/layouts/pure-min.css">
  <link rel="stylesheet" href="../css/layouts/side-menu.css">
</head>

<body>
<div id="layout">
   <a href="#menu" id="menuLink" class="menu-link">
   <span></span>
   </a>
   <div id="menu">
      <div class="pure-menu pure-menu-open">
         <a class="pure-menu-heading" href="#"><center>Raport</center></a>
         <?
#         if ($getuserid=="no")
#         {
#         }
#         else
#         {
         	$userid =$_GET['userid'];
#         }
#         $nama2  =$_GET['nama'];
         include ("../koneksi.inc.php");

         $query1=mysql_query("select * from guru where userid='$userid'" ,$koneksi);
         $jum=mysql_num_rows($query1);
         echo "<ul>";
               $row=mysql_fetch_array($query1);
               $password=$row["password"];
	       $pic=$userid;
	       $foto="../guru/".$pic.".jpg";
	       echo "<img src=\"$foto\" width=\"100%\" align=\"center\" border=\"0\"><center>";
	       echo $row["nama"];
	       echo "<br>";
	       echo "$userid</center>";
	       $nama=$row["nama"];
               echo "<li><a href=\"../login2.php?userid=$userid&pass=$password\">Depan</a></li>";
               echo "<li><a href=\"../index.php\">Logout</a></li>";
         echo "</ul>";
       echo "</div>";
    echo "</div>";

    # Bagian Utama

    ?>

    <div id="main">
        <div class="header">
            <h1><center>Aplikasi Raport</h1>
            <h2>Penentuan KD</center></h2>
        </div>
        <div class=\"content\">
<?
echo "<br><table class=\"pure-table\">";
$query1=mysql_query("select * from tugas where kodeguru like '%$userid%' order by mapelrombel",$koneksi);

$jumlah=mysql_num_rows($query1);
echo "<thead><tr>";
echo "<th>No</th>
   <th>Thn Ajr</th>
   <th>Smt</th>
   <th>Mapel</th>
   <th>Rombel</th>
   </tr></thead>";
$no=0;
while ($row=mysql_fetch_array($query1))
{
	$no++;
	$id         =$row["id"];
	$tasemester =$row["tasemester"];
	$tahunajaran=substr($tasemester,0,4);
	$semester   =substr($tasemester,4,1);
	$mapelrombel=$row["mapelrombel"];
	$kodemapel  =substr($mapelrombel,0,3);
	$rombel     =substr($mapelrombel,3,3);
	$jumlah_kd  =$row["jumlah_kd"];
	$kd         =$row["kd"];
	$query2=mysql_query("select * from mapel where kodemapel='$kodemapel'", $koneksi);
	while ($row2=mysql_fetch_array($query2))
	{
		$mapel=$row2["mapel"];
		$alias=$row2["alias"];
	}
	echo "<tr>";
	echo "<td>$no</td>";
	echo "<td>$tahunajaran</td>";
	echo "<td>$semester</td>";
	echo "<td>$alias ($mapel)</td>";
	echo "<td>$rombel</td>";
	echo "</tr>";
	echo "<tr class=\"pure-table-odd\">";
	echo "<td colspan=2>";
#--Kompetensi Dasar--
	echo "<center>Kompetensi Dasar<br>$jumlah_kd item";
	echo "<br><a href=\"definisi02.php?userid=$userid&id=$id&rombel=$rombel&mapel=$mapel\">Edit</a>";
	echo "</center></td><td colspan=3>";
	$h=1;
	for ($h ; $h <= $jumlah_kd ; $h++)
	{
		$h2=$h+1;
		$cariawal =$h.".";
		$cariakhir=$h2.".";
		$posawal  =strpos($kd,$cariawal,0);
		$posakhir =strpos($kd,$cariakhir,0);
		if ($h==$jumlah_kd)
		{
			$posakhir=strlen(rtrim($kd));
		}
		$panjangkd=$posakhir-$posawal;
		$itemkd=substr($kd,$posawal,$panjangkd);
		echo "$itemkd<br>";
	}
	echo "</td></tr>";
}
echo "</table>";
?>
       </div>
   </div>
</div>
<script src="../js/ui.js"></script>
</body>
</html>

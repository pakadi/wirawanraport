<?php
// Fungsi header dengan mengirimkan raw data excel
//header("Content-type: application/vnd-ms-excel");
// Mendefinisikan nama file ekspor "hasil-export.xls"
//header("Content-Disposition: attachment; filename=tutorialweb-export.xls");

         $userid   =$_GET['userid'];
         $tagnilai =$_GET['tagnilai'];
	 $rombel   =$_GET['rombel'];
	 $mapel    =$_GET['mapel'];
         include ("../koneksi.inc.php");

$filename=$rombel.$tagnilai.".xls";
// Fungsi header dengan mengirimkan raw data excel
header("Content-type: application/vnd-ms-excel");
// Mendefinisikan nama file ekspor 
header("Content-Disposition: attachment; filename=$filename");

$kodenilai=substr($tagnilai,8,3);
$query2=mysql_query("select * from jenis_nilai where kodenilai like '$kodenilai'",$koneksi);
while ($row2=mysql_fetch_array($query2))
{
	$jenistes=$row2["jenisnilai"];
}
$query1=mysql_query("select * from siswa where rombel_14='$rombel' order by nama",$koneksi);
$jumlah=mysql_num_rows($query1);

echo "<table class=\"pure-table\">";
echo "<tr><td colspan=7>Mapel = $mapel  |   Jenis : $jenistes ($kodenilai)</td></tr>";
echo "<thead><tr>"; 
echo "<th>No</th>
   <th>Tag Nilai</th>
   <th>Id Siswa</th>
   <th>Nama Peserta</th>
   <th>LP</th>
   <th>Rombel</th>";
if (substr($kodenilai,0,1)=="S")
{
	echo "<th>Nilai(A-D)</th>";
}
else
{
	echo "<th>Nilai</th>";
}
echo "</tr></thead>";
$no=0;
while ($row1=mysql_fetch_array($query1))
{
	$no++;
	$nama   =$row1["nama"];
	$idsiswa=$row1["userid"];
	$lp     =$row1["LP"];
	$query3 = mysql_query("select * from nilai where id_siswa = '$idsiswa' and tag_nilai= '$tagnilai'",$koneksi);
	if ($query3)
	{
		$row3=mysql_fetch_array($query3);
		$nilai=$row3["nilai"];
	}
	else
	{
		$nilai=1;
	}
 	if ($nilai==1) { $nilai="D"; }
    	if ($nilai==2) { $nilai="C"; }
      	if ($nilai==3) { $nilai="B"; }
  	if ($nilai==4) { $nilai="A"; } 	
	echo "<tr><td>$no</td>";
	echo "<td>$tagnilai</td>";
	echo "<td>$idsiswa</td>";
	echo "<td>$nama</td>";
	echo "<td>$lp</td>";
	echo "<td>$rombel</td>";
	echo "<td>$nilai</td></tr>";
}
echo "</table>";
?>
       </div>
   </div>
</div>
<script src="../js/ui.js"></script>
</body>
</html>

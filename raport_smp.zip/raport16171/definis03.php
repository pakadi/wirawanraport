<?php
$jumlahkd  =$_GET['jumlahkd'];
$kd        =$_GET['kd'];

include ("../koneksi.inc.php");

$update=mysql_query ("update tugas set jumlah_kd='$jumlahkd',kd='$kd", $koneksi);
echo "Perbaikan soal telah di update";

include ("definisi01.php");
?>

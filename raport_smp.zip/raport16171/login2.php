<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
  <title>Raport - Depan</title>
  <link rel="stylesheet" href="css/layouts/pure-min.css">
  <link rel="stylesheet" href="css/layouts/side-menu.css">
</head>

<body>
<div id="layout">
    <!-- Menu toggle -->
    <a href="#menu" id="menuLink" class="menu-link">
    <!-- Hamburger icon -->
    <span></span>
    </a>

    <div id="menu">
        <div class="pure-menu pure-menu-open">
            <a class="pure-menu-heading" href="#"><center>SMP PGRI</center></a>


<?php
	$userid2 =$_GET['userid'];
   	$pass2   =$_GET['pass'];
   	$userid  =strtoupper($userid2);
   	$pass    =strtolower($pass2);

   include ("koneksi.inc.php");
   $vuserid=substr($userid,0,1);
   if ($vuserid=="A")
   {
	$file="admin";
   }
   else
   {
  	if ($vuserid=="G")
	{
		$file="guru";
	}
	else
	{
		$file="siswa";
	}
   }
   $query1=mysql_query("select * from $file where userid='$userid'" ,$koneksi);
   $jum=mysql_num_rows($query1);
   if ($jum==0)
   {
      echo " <center><b>$userid ???</b><br>User ID ini belum ada pada daftar $file...";
      echo " <a href=\"index.php\">kembali</center></a>";
     exit;
   }
   echo "      <ul>";
               $pesan=0;
               $query2=mysql_query("select * from pesan where userid='$userid'",$koneksi);
               while ($row=mysql_fetch_array($query2))
               $pesan=mysql_num_rows($query2);	
               $row=mysql_fetch_array($query1);
               $password=$row["password"];
               if ($password==$pass)
               {
	          $pic=$userid;
	          $foto="$file/".$pic.".jpg";
	          echo "<img src=\"$foto\" width=\"100%\" align=\"center\" border=\"0\"><center>";
	          echo $row["nama"];
	          echo "<br>";
	          echo "$userid</center>";
	          $nama=$row["nama"];
               }
               else
               {
	          echo "<center>password yang anda masukkan salah....";
   	          echo " <a href=\"index.php\">kembali</center></a></ul>";
                  exit;
               }
	       $fileprofile="profile".$file.".php";
               echo "<li><a href=\"pesan01.php?userid=$userid\">Ada $pesan pesan</a></li>";
               echo "<li><a href=\"index.php\">Logout</a></li>";
               echo "</ul>";
           echo "</div>
           </div>";
# Bagian Utama
    echo "<div id=\"main\">
        <div class=\"header\">
            <h1>Raport - Depan</h1>
            <h2>Aplikasi Raport Online</h2>
        </div>

        <div class=\"content\">";
	$query3=mysql_query("select * from rombel where kodewalas='$userid'", $koneksi);
	$walikelas=mysql_num_rows($query3);
	$row3=mysql_fetch_array($query3);
	$rombel=$row3["rombel"];	
#	if ($query3)
#	{
#		$walikelas=1;
#	}
   if ($vuserid=="A")
   {
	echo "<ul>";
	echo "<li><a href=\"admin/nilai01.php?userid=$userid&rombel=$rombel\">Lihat Leger model 2</a></li>";
	echo "<li><a href=\"admin/nilai02.php?userid=$userid&rombel=$rombel\">Lihat Leger model 3</a></li>";
	echo "</ul>";
   }
   else
   {
	if ($vuserid=="G")
	{
		echo "<ul>";
		echo "<li><a href=\"guru/definisi01.php?userid=$userid&nama=$nama\">Definisikan Nilai</a></li>";
		echo "<li><a href=\"guru/lihat01.php?userid=$userid&nama=$nama\">Ekspor / Download Nilai</a></li>";
		echo "<li><a href=\"guru/import01.php?userid=$userid\">Impor / Upload Nilai</a></li>";
		echo "<li><a href=\"guru/entri01.php?userid=$userid\">Entri Nilai</a></li>";
		echo "<li><a href=\"guru/edit01.php?userid=$userid\">Lihat Nilai</a></li>";
		echo "<li><a href=\"admin/utslegerangka01.html?userid=$userid\">Leger Huruf UTS</a></li>";
		echo "<li><a href=\"admin/utslegerhuruf01.html?userid=$userid\">Leger Angka UTS</a></li>";
		if ($walikelas)
		{
			echo "<li><a href=\"guru/absen01.php?userid=$userid&rombel=$rombel\">Isi Absen Kelas</a></li>";
			echo "<li><a href=\"guru/leger01.php?userid=$userid&rombel=$rombel\">Lihat Leger umum UAS</a></li>";
			echo "<li><a href=\"admin/nilai01.php?userid=$userid&rombel=$rombel\">Lihat Leger model UAS angka</a></li>";
			echo "<li><a href=\"admin/nilai02.php?userid=$userid&rombel=$rombel\">Lihat Leger model UAS huruf</a></li>";
			echo "<li><a href=\"guru/legeruts01.php?userid=$userid&rombel=$rombel\">Lihat Leger umum UTS</a></li>";
			echo "<li><a href=\"admin/nilaiuts01.php?userid=$userid&rombel=$rombel\">Lihat Leger model UTS angka</a></li>";
			echo "<li><a href=\"admin/nilaiuts02.php?userid=$userid&rombel=$rombel\">Lihat Leger model UTS huruf</a></li>";

		}
		echo "</ul>";
	}
	else
	{
		echo "<ul>";
		echo "<li><a href=\"tes/nilaiku.php?userid=$userid\">Nilai</a></li>";
		echo "<li><a href=\"tes/hasiltes.php?userid=$userid\">Hasil Tes</a></li>";
		echo "<li><a href=\"index.php\">Logout</a></li>";
		echo "</ul>";
	}
   }
   ?>

                Belajar, Berlatih, Berprestasi
            </p>
        </div>
    </div>
</div>
<script src="js/ui.js"></script>
</body>
</HTML>

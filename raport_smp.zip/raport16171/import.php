<title>Script Import File Excel</title>
<h1>Script Import File Excel</h1>
<form method="post" enctype="multipart/form-data" action="jalan.php">
Pilih File Excel*: <input name="fileexcel" type="file"> <input name="upload" type="submit" value="Import">
</form>
* file yang bisa di import adalah .xls (Excel 2003-2007).

<title>Raport - Import Nilai</title>
<h1>Import nilai Excel (xls)</h1>
<form method="post" enctype="multipart/form-data" action="import02.php">
Pilih File Excel*: <input name="fileexcel" type="file"> <input name="upload" type="submit" value="Import">
</form>
* file yang bisa di import adalah .xls (Excel 2003-2007).

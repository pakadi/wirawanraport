<?php
$jumlahkd  =$_POST['jumlahkd'];
$kd        =$_POST['kd'];
$userid    =$_POST['userid'];
$id        =$_POST['id'];

include ("../koneksi.inc.php");

$update=mysql_query ("update tugas set jumlah_kd='$jumlahkd',kd='$kd' where id='$id'", $koneksi);
echo "KD telah di update";
echo "<a href=\"definisi01.php?userid=$userid\"><br>Klik disini</a>";
?>

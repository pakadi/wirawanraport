<?php
$userid   =$_GET['userid'];
$rombel   =$_GET['rombel'];
include ("../koneksi.inc.php");
include ("fungsi.php");

$filename=$rombel."_huruf.xls";
// Fungsi header dengan mengirimkan raw data excel
header("Content-type: application/vnd-ms-excel");
// Mendefinisikan nama file ekspor 
header("Content-Disposition: attachment; filename=$filename");

$query2=mysql_query("select * from siswa where rombel_14='$rombel' order by nama limit 50",$koneksi);
$jumlah=mysql_num_rows($query2);
echo "<table class=\"pure-table\">";
echo "<thead><tr>";
echo "<th>No</th>
   <th>Nama Peserta</th>
   <th>LP</th>";
$query3=mysql_query("select * from mapel where kurikulum='2013' order by urutan", $koneksi);
while ($row3=mysql_fetch_array($query3))
{
        echo "<th>";
        echo $row3["alias"];
        echo "_KI12</th><th>";
        echo $row3["alias"];
        echo "_KI3</th><th>";
        echo $row3["alias"];
        echo "_KI4</th>";

}
echo "</tr></thead>";
$no=0;
while ($row2=mysql_fetch_array($query2))
{
        $no++;
        $nama   =$row2["nama"];
        $idsiswa=$row2["userid"];
        $lp     =$row2["LP"];
        if ($no & 1)
        {
                echo "<tr>";
        }
        else
        {
                echo "<tr class=\"pure-table-odd\">";
        }
        echo "<td>$no</td>";
        echo "<td>$nama</td>";
        echo "<td>$lp</td>";
        $query6=mysql_query("select * from mapel where kurikulum='2013' order by urutan", $koneksi);
        while ($row6=mysql_fetch_array($query6))
        {
                $kodemapel=$row6["kodemapel"];
                $query4=mysql_query("select * from jenis_nilai", $koneksi);
                $pembagiki3 =0;
                $pembagiki4 =0;
                $pembagiki12=0;
                $nilaiki3   =0;
                $nilaiki4   =0;
                $nilaiki12  =0;
                $nilaiuts   =0;
                $nilaiuas   =0;
                while ($row4=mysql_fetch_array($query4))
                {
                        $kodenilai=$row4["kodenilai"];
                        $tag   =$idsiswa."15162".$kodemapel.$kodenilai;
                        $query5=mysql_query("select * from nilai where tag='$tag'", $koneksi);
                        $jumlah=mysql_num_rows($query5);
                        if ($jumlah)
                        {
                                $row5=mysql_fetch_array($query5);
                                $nilai=$row5["nilai"];
                                if (substr($kodenilai,0,1)=="H" || substr($kodenilai,1)=="T")
                                {
                                        $pembagiki3++;
                                        $nilaiki3=$nilaiki3+$nilai;
                                }
                                elseif (substr($kodenilai,0,1)=="P")
                                {
                                        $pembagiki4++;
                                        $nilaiki4=$nilaiki4+$nilai;
                                }
                                elseif (substr($kodenilai,0,1)=="S")
                                {
                                        $pembagiki12++;
                                        $nilaiki12=$nilaiki12+$nilai;
                                }
                                elseif ($kodenilai=="U01")
                                {
                                        $nilaiuts=$nilai;
                                }
                                elseif ($kodenilai=="U02")
                                {
                                        $nilaiuas=$nilai;
                                }
                        }
                        else
                        {
                        }
                }
                $nilaiki3ok =@($nilaiki3/$pembagiki3);
                $nilaiki4ok =@($nilaiki4/$pembagiki4);
                $nilaiki12ok=@($nilaiki12/$pembagiki12);
                $nilaiki3ok =number_format($nilaiki3ok,2);
                $nilaiki4ok =number_format($nilaiki4ok,2);
                $nilaiki12ok=number_format($nilaiki12ok,2);
                $nilaiki3b  =(($nilaiki3ok*6)+($nilaiuts*4))/10;
                $nilaiki3b  =number_format($nilaiki3b,2);
                $ki4  = $nilaiki4ok / 25;
                $ki3  = $nilaiki3b / 25;
                $ki4h = kehuruf($ki4);
                $ki3h = kehuruf($ki3);
                $ki12h= sikap($nilaiki12ok);
                echo "<td><font color=\"green\">$ki12h</td><td><font color=\"blue\">$ki3h</td><td><font color=\"black\">$ki4h</td>";
        }
        echo "</tr>";
}
echo "</table>";
?>

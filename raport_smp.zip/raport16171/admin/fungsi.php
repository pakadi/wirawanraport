<?
function kehuruf($nil)
{
	if ($nil <= 1.17) { $huruf="<font color=red>D"; }
	elseif ($nil <= 1.5) { $huruf="<font color=red>D+"; }
	elseif ($nil <= 1.84) { $huruf="<font color=red>C-"; }
	elseif ($nil <= 2.17) { $huruf="<font color=red>C"; }
	elseif ($nil <= 2.5) { $huruf="<font color=red>C+"; }
	elseif ($nil <= 2.84) { $huruf="B-"; }
	elseif ($nil <= 3.17) { $huruf="B"; }
	elseif ($nil <= 3.5) { $huruf="B+"; }
	elseif ($nil <= 3.84) { $huruf="A-"; }
	else { $huruf="A"; }
	return $huruf;
}
function sikap($nil)
{
	$nilai=round($nil,0);
	if ($nilai==0)     { $ket="";  }
	elseif ($nilai==1) { $ket="<font color=red>K"; }
	elseif ($nilai==2) { $ket="<font color=red>C"; }
	elseif ($nilai==3) { $ket="B"; }
	else { $ket="SB"; }
	return $ket;
}	
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
  <title>Raport - Leger Kelas</title>
  <link rel="stylesheet" href="../css/layouts/pure-min.css">
  <link rel="stylesheet" href="../css/layouts/side-menu.css">
</head>

<body>
<div id="layout">
   <a href="#menu" id="menuLink" class="menu-link">
   <span></span>
   </a>
   <div id="menu">
      <div class="pure-menu pure-menu-open">
         <a class="pure-menu-heading" href="#"><center>Raport</center></a>
         <?
         $userid   =$_GET['userid'];
	 $rombel   =$_GET['rombel'];
         include ("../koneksi.inc.php");

         $query1=mysql_query("select * from guru where userid='$userid'" ,$koneksi);
         $jum=mysql_num_rows($query1);
         echo "<ul>";
               $row=mysql_fetch_array($query1);
               $password=$row["password"];
	       $pic=$userid;
	       $foto="../guru/".$pic.".jpg";
	       echo "<img src=\"$foto\" width=\"100%\" align=\"center\" border=\"0\"><center>";
	       echo $row["nama"];
	       echo "<br>";
	       echo "$userid</center>";
	       $nama=$row["nama"];
               echo "<li><a href=\"../index.php\">Logout</a></li>";
         echo "</ul>";
       echo "</div>";
    echo "</div>";
    # Bagian Utama
    ?>
    <div id="main">
        <div class="header">
            <h1><center>Aplikasi Raport</h1>
            <h2>Leger Kelas UTS Angka</center></h2>
        </div>
        <div class=\"content\">
<?php
echo "<a href=\"nilaiuts01b.php?userid=$userid&rombel=$rombel\"> ---- Export ke excel</a>";
$query2=mysql_query("select * from siswa where rombel_14='$rombel' order by nama limit 50",$koneksi);
$jumlah=mysql_num_rows($query2);
echo "<table class=\"pure-table\">";
echo "<thead><tr><td rowspan=2>No</td>
   <td rowspan=2>Nama Peserta</td>
   <td rowspan=2>LP</td>";

$query3=mysql_query("select * from mapel where kurikulum='2013' order by urutan", $koneksi);
while ($row3=mysql_fetch_array($query3))
{
	$kodemapel=$row3["kodemapel"];
	$cariguru=$kodemapel.$rombel;
	$query3c=mysql_query("select * from tugas where mapelrombel='$cariguru'", $koneksi);
	$row3c=mysql_fetch_array($query3c);
	$cariguru2=$row3c["kodeguru"];
	$query3d=mysql_query("select * from guru where userid='$cariguru2'", $koneksi);
	$row3d=mysql_fetch_array($query3d);
	$gurumapel=$row3d["nama"];
	echo "<td colspan=3>";
	echo "<center>$gurumapel";
	echo "</td>";
}
echo "<td rowspan=2>Sakit</td>";
echo "<td rowspan=2>Izin</td>";
echo "<td rowspan=2>Alpa</td>";
echo "</tr><tr>";

$query3b=mysql_query("select * from mapel where kurikulum='2013' order by urutan", $koneksi);
while ($row3b=mysql_fetch_array($query3b))
{
	echo "<td>";
	echo $row3b["alias"];
	echo "_KI3</td><td>";
	echo $row3b["alias"];
	echo "_KI4</td><td>";
	echo $row3b["alias"];
	echo "_KI12</td>";
}
echo "</tr></thead>";
$no=0;
while ($row2=mysql_fetch_array($query2))
{
	$no++;
	$nama   =$row2["nama"];
	$idsiswa=$row2["userid"];
	$lp     =$row2["LP"];
	if ($no & 1)
	{
		echo "<tr>";
	}
	else
	{
		echo "<tr class=\"pure-table-odd\">";
	}
	
	$query9=mysql_query("select * from absen where id_siswa='$idsiswa'", $koneksi);
	$row9=mysql_fetch_array($query9);
	$sakit=$row9["sakit"];
	$izin =$row9["izin"];
	$alpa =$row9["alpa"];
	
	echo "<td>$no</td>";
	echo "<td>$nama</td>";
	echo "<td>$lp</td>";
	$query6=mysql_query("select * from mapel where kurikulum='2013' order by urutan", $koneksi);
	while ($row6=mysql_fetch_array($query6))
	{
		$kodemapel=$row6["kodemapel"];
		$query4=mysql_query("select * from jenis_nilai", $koneksi);
		$pembagiki3 =0;
		$pembagiki4 =0;
		$pembagiki12=0;
		$nilaiki3   =0;
		$nilaiki4   =0;
		$nilaiki12  =0;
		$nilaiuts   =0;
		while ($row4=mysql_fetch_array($query4))
		{
			$kodenilai=$row4["kodenilai"];
			$tag   =$idsiswa."15162".$kodemapel.$kodenilai;
			$query5=mysql_query("select * from nilai where tag='$tag'", $koneksi);
			$jumlah=mysql_num_rows($query5);
			if ($jumlah)
			{
				$row5=mysql_fetch_array($query5);
				$nilai=$row5["nilai"];
				if (substr($kodenilai,0,1)=="H" || substr($kodenilai,1)=="T")
				{
					$pembagiki3++;
					$nilaiki3=$nilaiki3+$nilai;
				}
				elseif (substr($kodenilai,0,1)=="P")
				{
					$pembagiki4++;
					$nilaiki4=$nilaiki4+$nilai;
				}
				elseif (substr($kodenilai,0,1)=="S")
				{
					$pembagiki12++;
					$nilaiki12=$nilaiki12+$nilai;
				}
				elseif ($kodenilai=="U01")
				{
					$nilaiuts=$nilai;
				}
			}
			else
			{
			}
		}
		$nilaiki3ok =@($nilaiki3/$pembagiki3);
		$nilaiki4ok =@($nilaiki4/$pembagiki4);
		$nilaiki12ok=@($nilaiki12/$pembagiki12);
		$nilaiki3ok =number_format($nilaiki3ok,2);
		$nilaiki4ok =number_format($nilaiki4ok,2);
		$nilaiki12ok=number_format($nilaiki12ok,2);
		$nilaiki3b  =(($nilaiki3ok*60)+($nilaiuts*40))/100;
		$nilaiki3b  =number_format($nilaiki3b,2);
		$ki4  = $nilaiki4ok / 25;
		$ki3  = $nilaiki3b / 25;
		$ki4  = number_format($ki4,2);
		$ki3  = number_format($ki3,2);
		echo "<td><font color=\"green\">$ki3</td><td><font color=\"blue\">$ki4</td><td><font color=\"brown\">$nilaiki12ok</td>";
	}
	echo "<td>$sakit</td><td>$izin</td><td>$alpa</td>";
	echo "</tr>";
}
echo "</table>";
?>
       </div>
   </div>
</div>
<script src="../js/ui.js"></script>
</body>
</html>

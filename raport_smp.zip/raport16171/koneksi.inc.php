<?php
$host="localhost";
$db="raport";
$user="root";
$passw="";
$koneksi=mysql_connect($host, $user, $passw);
mysql_select_db($db,$koneksi);
?>
